from loanapp.models import Account, Profile, Loan, Expense, Person
from django.contrib.auth.models import User
from django import forms
from django.contrib.auth.forms import UserCreationForm
# from easy_select2 import *

class ExpenseForm(forms.ModelForm):
    class Meta:
        model = Expense
        exclude = ['profile']

# Modified choice field
class ChoiceFieldNoValidation(forms.ChoiceField):
    def validate(self, value):
        pass

# Initial loan creation on dashboard
class LoanForm1(forms.ModelForm):
    borrower = ChoiceFieldNoValidation()
    class Meta:
        model = Loan
        fields = ['purpose'] 

class LoanForm2(forms.ModelForm):
    class Meta:
        model = Loan
        fields = ['original_amt','monthly_amt','interest']


class ProfileForm(forms.ModelForm):
    class Meta:
        model = Profile
        exclude = ['loan']

class UserCreateForm(UserCreationForm):
    email = forms.EmailField(required=True)
    class Meta:
        model = User
        fields = ("username", "email", "password1", "password2")
    def save(self, commit=True):
        user = super(UserCreateForm, self).save(commit=False)
        user.email = self.cleaned_data["email"]
        if commit:
            user.save()
        return user



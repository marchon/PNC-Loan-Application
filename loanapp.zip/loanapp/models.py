from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.core.exceptions import ObjectDoesNotExist

class Expense(models.Model):
	profile = models.ForeignKey('Profile', on_delete=models.CASCADE, null=True)
	category = models.CharField(max_length=100)
	amount = models.DecimalField(max_digits=10, decimal_places=2)
	def __str__(self):
		return self.category + " : " + str(self.amount)

class Profile(models.Model):
	loan = models.ForeignKey('Loan', on_delete=models.CASCADE, null=True)
	income = models.DecimalField(max_digits=10, decimal_places=2, default='0.0')
	def __str__(self):
		return self.income

class MonthlyPayment(models.Model):
	loan = models.ForeignKey('Loan', on_delete=models.CASCADE, null=True)
	date = models.DateField(auto_now=False)
	remaining_amt = models.DecimalField(max_digits=100, decimal_places=2, null=True)
	interest = models.DecimalField(max_digits=10, decimal_places=5)
	monthly_amt = models.DecimalField(max_digits=10, decimal_places=2, null=True)
	def __str__(self):
		return "Monthly payment is " + self.date + self.remaining_amt + self.interest + self.monthly_amt

class LoanManager(models.Manager):
    def create_loan(self, acct, person, purpose):
        new_loan = self.create(acct=acct,person=acct.person_set.filter(name=person).latest('id'),purpose=purpose)
        return new_loan

class Loan(models.Model):
	person = models.ForeignKey('Person',null=True)
	acct = models.ForeignKey('Account', on_delete=models.CASCADE, null=True)
	active = models.BooleanField(default=False)
	purpose = models.CharField(max_length=500)
	original_amt = models.DecimalField(max_digits=100, decimal_places=2, null=True)
	remaining_amt = models.DecimalField(max_digits=100, decimal_places=2, null=True)
	interest = models.DecimalField(max_digits=10, decimal_places=5, null=True)
	min_monthly_amt = models.DecimalField(max_digits=10, decimal_places=2, null=True)
	monthly_amt = models.DecimalField(max_digits=10, decimal_places=2, default='10.0', null=True)
	objects = LoanManager()
	def __str__(self):
		return "Loan summary : \n" + "Person : " + str(self.person)
		# + "\nPurpose : " + self.purpose 
		# + "\nRemaining amount : " + self.remaining_amt
		# + "\nInterest : " + self.interest
		# + "\nMonths left : " + str(self.remaining_amt/self.monthly_amt)

class PersonManager(models.Manager):
    def create_person(self, acct, name):
    	try:
    		return acct.person_set.get(name=name)
    	except Person.DoesNotExist:
    		print("dne error")
    		return self.create(acct=acct,name=name)
    	else:
    		print("other error")

class Person(models.Model):
	acct = models.ForeignKey('Account', on_delete=models.CASCADE, null=True)
	name = models.CharField(max_length=255)
	objects = PersonManager()
	def __str__(self):
		return self.name

class Account(models.Model):
	user = models.OneToOneField(User, on_delete=models.CASCADE, null=True)
	def __str__(self):
		return self.user.username

# Function to create family account every time user is created
def createUserAccount(sender, instance, created, **kwargs):
    if created:
       account, created = Account.objects.get_or_create(user=instance)

post_save.connect(createUserAccount, sender=User)



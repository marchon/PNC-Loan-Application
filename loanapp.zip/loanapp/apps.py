from django.apps import AppConfig


class LoanappConfig(AppConfig):
    name = 'loanapp'

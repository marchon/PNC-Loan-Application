from django.contrib import admin
from loanapp.models import Person
